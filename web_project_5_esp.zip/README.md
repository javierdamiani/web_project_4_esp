# Proyecto 5: Alrededor de los Estados Unidos

By. Javier Damiani

El proyecto 4 consistió en hacer una página web que presente imágenes y el perfil de un explorador. También debe aparecer un popUp para editar la información del explorador. Para el desarrollo de este proyecto se utilizó la tecnología HTML, CSS y JavaScript. Siendo HTML y CSS para la maquetación de la web y JavaScript para la interacción entre el usuario y la web.

Se continuó con la base del proyecto anterior, se agregaron funcionalidades a la página tales como poder añadir tarjetas, borrar tarjetas, darles like, así como el poder agrandar las imágenes de las tarjetas.
El link para visitar la Web es el siguiente: https://javierdamiani.github.io/web_project_4_esp.github.io/
